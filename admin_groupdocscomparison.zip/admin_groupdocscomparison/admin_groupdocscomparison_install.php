<?php

	$module_info['name'] = 'Admin GroupDocs Comparison';

	$module_info['desc'] = 'Sign Word, Exel, PDF, Images and other files using GroupDocs Embed Key and File ID';

	$module_info['version'] = 1.0;


?>